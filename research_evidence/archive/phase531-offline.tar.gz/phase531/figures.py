"""Export display-ready grouped CV figures and flat analysis tables."""
import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
import numpy as np


STATE = ("x","y","z","vx","vy","vz","roll","pitch","yaw")
GROUPS=("xyz_mm","velocity_mm_s","attitude_mrad")
COLORS=("#285383","#2a7967","#ac641c","#874563","#454b7f")
PRIMARY="L1a"


def write_csv(path, rows):
    with path.open("x",newline="") as stream:
        d=csv.DictWriter(stream,list(rows[0]))
        d.writeheader()
        d.writerows(rows)


def save(fig,root,name):
    for suffix in ("png","svg"):
        fig.savefig(root/f"cv_{name}.{suffix}",dpi=195)
    plt.close(fig)


def data_rows(summary):
    scores, folds = [], []
    for row in summary["candidates"]:
        meta={k:row[k] for k in ("profile","rho","beta","episode_count","status")}
        entry=dict(meta)
        folded=[dict(meta,fold=i+1) for i in range(5)]
        metrics=((f"{scope}_{name}",row[scope][name]) for scope in ("full","terminal") for name in (*GROUPS,"axes_si"))
        for base, x in metrics:
            keys=[base] if "axes_si" not in base else [base.replace("axes_si",key+"_si") for key in STATE]
            for i,key in enumerate(keys):
                axis=lambda v: v[i] if isinstance(v,list) else v
                for stat in ("episode_mean","fold_mean","fold_sd","worst_fold"):
                    entry[f"{key}_{stat}"]=axis(x[stat])
                for f,value in zip(folded,x["fold_values"]):
                    f[key]=axis(value)
        for key in ("init_slack","g_norm","g_penalty","init_penalty"):
            entry[f"{key}_episode_mean"]=row[key]["episode_mean"]
            for stat in ("fold_sd","worst_fold"):
                entry[f"{key}_{stat}"]=row[key][stat]
            for f,v in zip(folded,row[key]["fold_values"]):
                f[key]=v
        scores.append(entry)
        folds.extend(folded)
    return scores,folds


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("results",type=Path)
    p.add_argument("folds",type=Path)
    p.add_argument("output",type=Path)
    a=p.parse_args()
    a.output.mkdir()
    plt.rcParams.update({"font.size":11,"axes.spines.top":False,"axes.spines.right":False,
                         "legend.frameon":False,"axes.grid":True,"grid.alpha":.18})
    s=json.loads((a.results/"summary.json").read_text())
    cfg=json.loads(a.folds.read_text())
    rho,beta=cfg["rho"],cfg["beta"]
    rows={(r["profile"],r["rho"],r["beta"]):r for r in s["candidates"]}
    current=tuple(s["current"])
    finalists=[tuple(x) for x in s["additional"]]
    shortlist=[current,*finalists]
    names=["Current","Candidate A","Candidate B"][:len(shortlist)]
    data,fold_metrics=data_rows(s)
    write_csv(a.output/"candidate_metrics.csv",data)
    write_csv(a.output/"fold_metrics.csv",fold_metrics)

    def xyz(level, point):
        return rows[(level,*point)]["full"]["xyz_mm"]["episode_mean"]

    for level, tag in (("L0","l0_heatmap"),(PRIMARY,"l1_heatmap")):
        fig,ax=plt.subplots(figsize=(8,5),layout="constrained")
        z=np.array([[xyz(level,(r,b)) for b in beta] for r in rho])
        a_=ax.imshow(z,cmap="viridis_r",aspect="auto")
        for i in range(5):
            for j in range(5):
                frac=(z[i,j]-z.min())/(z.max()-z.min())
                ax.text(j,i,f"{z[i,j]:.3f}",ha="center",va="center",color="white" if frac>.57 else "#171c24")
        handles=[]
        for i,(r,b) in enumerate(shortlist):
            edge=("#ef762e","#163b55","#791d68")[i]
            cell=(beta.index(b)-.42,rho.index(r)-.42)
            ax.add_patch(Rectangle(cell,.84,.84,fill=False,edgecolor=edge,linewidth=2.3))
            handles.append(Patch(facecolor="none",edgecolor=edge,linewidth=2.3,label=names[i]))
        ax.grid(False)
        ax.set_xticks(range(5),[f"{b:g}" for b in beta])
        ax.set_yticks(range(5),[f"{r:g}" for r in rho])
        ax.set(xlabel="Initialization weight β",ylabel="Ridge factor ρ",
               title=f"{level} • XYZ full-horizon RMSE (mm, equal episode weight)")
        ax.legend(handles=handles,loc="upper left",bbox_to_anchor=(0,-.16),ncol=len(shortlist))
        fig.colorbar(a_,ax=ax,shrink=.84)
        save(fig,a.output,tag)

    fig,axs=plt.subplots(1,2,figsize=(11,4.4),layout="constrained")
    for ax,level in zip(axs,("L0",PRIMARY)):
        for i,b in enumerate(beta):
            ax.semilogx(rho,[xyz(level,(r,b)) for r in rho],"o-",color=COLORS[i],label=f"β={b:g}")
        ax.scatter(*[current[0],xyz(level,current)],marker="*",color="#ef762e",s=160,zorder=6,label="Current")
        ax.set(title=level,xlabel="Ridge factor ρ",ylabel="XYZ RMSE (mm)")
    axs[1].legend(loc="upper right")
    fig.suptitle("Regularization validation curves")
    save(fig,a.output,"curves")

    fig,ax=plt.subplots(figsize=(8.2,5),layout="constrained")
    for i,r in enumerate(rho):
        ax.plot([xyz("L0",(r,b)) for b in beta],[xyz(PRIMARY,(r,b)) for b in beta],"o-",color=COLORS[i],label=f"ρ={r:g}")
    for i,point in enumerate(shortlist):
        ax.scatter(xyz("L0",point),xyz(PRIMARY,point),marker=["*","D","s"][i],s=152,
                   linewidths=.8,edgecolor="white",color=["#ef762e","#163b55","#563075"][i],label=names[i],zorder=10)
    ax.set(xlabel="L0 full-horizon XYZ RMSE (mm)",ylabel="L1a full-horizon XYZ RMSE (mm)",
           title="Nominal versus noisy prediction")
    ax.legend(ncol=2)
    save(fig,a.output,"nominal_noisy_tradeoff")

    fig,axs=plt.subplots(1,2,figsize=(11,4.4),layout="constrained")
    for ax,metric,title in zip(axs,("init_slack","g_norm"),("Normalized initialization residual RMS","Coefficient norm ||g||")):
        for i,b in enumerate(beta):
            ax.semilogx(rho,[rows[(PRIMARY,r,b)][metric]["episode_mean"] for r in rho],
                        "o-",color=COLORS[i],label=f"β={b:g}")
        value=rows[(PRIMARY,*current)][metric]["episode_mean"]
        ax.scatter(current[0],value,marker="*",color="#ef762e",s=160,label="Current",zorder=10)
        ax.set(title=title,xlabel="Ridge factor ρ",ylabel="Equal-episode mean")
    axs[1].legend()
    fig.suptitle("L1a initialization fit and coefficient sensitivity")
    save(fig,a.output,"initialization_and_g")

    fig,axs=plt.subplots(1,2,figsize=(11,4.6),layout="constrained")
    for i,point in enumerate(shortlist):
        for j,level in enumerate(("L1a","L1b")):
            m=rows[(level,*point)]["full"]["xyz_mm"]
            vals=m["fold_values"]
            axs[j].scatter(np.arange(1,6)+(i-1)*.11,vals,
                           color=["#ef762e","#285383","#2a7967"][i],label=names[i],s=36)
            axs[j].axhline(m["fold_mean"],color=["#ef762e","#285383","#2a7967"][i],ls=":",alpha=.7)
            axs[j].set(title=f"{level} · fold out of sample",xlabel="Held-out fold",ylabel="XYZ RMSE (mm)",xticks=range(1,6))
    axs[1].legend()
    fig.suptitle("Fold uncertainty and reproducibility across noise seeds")
    save(fig,a.output,"fold_stability")


if __name__=="__main__":
    main()
