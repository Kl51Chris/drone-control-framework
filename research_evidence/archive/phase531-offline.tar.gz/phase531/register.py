import json
from pathlib import Path
import sys

import numpy as np

manifest=json.loads(Path("log/phase3-v1/manifest.json").read_text())
episodes=sorted(e["processed"] for e in manifest["episodes"] if e["split"]=="train")
assert len(episodes)==11 and len(set(episodes))==11
permutation=np.random.default_rng(653100).permutation(len(episodes))
held=[sorted(episodes[i] for i in group) for group in np.array_split(permutation,5)]
plan=dict(episode_order=episodes,folds=[
    dict(fold=i+1,train=[e for e in episodes if e not in group],held_out=group)
    for i,group in enumerate(held)], seeds={"L0":None,"L1a":653101,"L1b":653102,"L2":653103},
    rho=[1e-4,3e-4,1e-3,3e-3,1e-2],beta=[.0625,.125,.25,.5,1.])
with Path(sys.argv[1]).open("x") as out:
    json.dump(plan,out,indent=2)
