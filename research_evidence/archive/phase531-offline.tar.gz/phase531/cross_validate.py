"""Episode-grouped Phase 5.3.1 conditional prediction using production DeePC matrices."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from time import perf_counter

import numpy as np
from scipy import linalg

from experiments.measurement_noise import MeasurementNoise
from tools.shared_dataset import hankel
from velocity_control_framework.controllers.outer_loop_deepc import (
    OuterLoopDeePCConfig, OuterLoopDeePCController, training_blocks,
)
from velocity_control_framework.interfaces import DroneState


T, N = 6, 25
CURRENT = (.001, .25)
GROUPS = ("xyz_mm", "velocity_mm_s", "attitude_mrad")
PCTS = [50, 95, 99, 100]


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def measure_spectrum(matrix):
    s = np.linalg.svd(matrix, compute_uv=False)
    rank = int(np.count_nonzero(s > s[0]*1e-4))
    return dict(shape=list(matrix.shape), sigma_max=float(s[0]), sigma_min=float(s[-1]),
                rank_1e4=rank, condition=float(s[0]/s[-1]) if s[-1]>0 else None,
                effective_condition=float(s[0]/s[rank-1]), relative_spectrum=(s/s[0]).tolist())


def diagnose_model(model, u, y, episodes):
    h = (u/model._us).reshape(len(u),-1).T
    output = (y/model._ys).reshape(len(y),-1).T
    checks = {
        "u_scale":model._us.tolist(), "y_scale":model._ys.tolist(),
        "training_columns":len(u), "latent_rank":model._n_decision-4*N,
        "input":measure_spectrum(h), "joint":measure_spectrum(np.vstack((h,output))),
        "pe":{str(order):measure_spectrum(hankel(episodes,"u",N+T+order)/
                                       np.tile(model._us,N+T+order)[:,None]) for order in (9,16,29)},
    }
    return h, checks


def observed(y, seed, level):
    profile = MeasurementNoise("none" if level==0 else "iid-small",level,seed)
    used=np.empty_like(y)
    deltas=[]
    for i,row in enumerate(y):
        d=DroneState(position=row[:3], velocity=row[3:6],roll=row[6], pitch=row[7],
                     yaw=row[8],timestamp=i*.02,p=0.,q=0.,r=0.)
        _, log = profile.apply(d,i)
        used[i] = log["used"][:9]
        deltas.append(log["delta"])
    return used, sha256(np.asarray(deltas,dtype="<f8").tobytes()).hexdigest()


def prepare(model, ep, noisy):
    fixed, residual, free, target, start = [],[],[],[],[]
    for k in range(25,len(ep["y"])-N):
        anchor = np.r_[noisy[k,:3],np.zeros(6)]
        past = ((noisy[k-T+1:k+1]-anchor)/model._ys).ravel()[model._use_y]
        up = (ep["u"][k-T:k]/model._us).ravel()
        uf = ep["u"][k:k+N].ravel()
        residual.append(past-model._past_offset@up-model._past_map[:,:4*N]@uf)
        g = model._lift_past@up+model._lift_free[:,:4*N]@uf
        fixed.append(g)
        prediction = model._future_offset@up+model._forced[:,:4*N]@uf
        free.append(prediction.reshape(N,9)+anchor)
        target.append(ep["truth"][k+1:k+N+1])
        start.append(k)
    return tuple(np.asarray(v) for v in (fixed,residual,free,target,start))


def metric(values):
    return dict(axes_si=values.tolist(), **{
        group:float(1000*np.sqrt(np.mean(values[3*i:3*i+3]**2)))
        for i,group in enumerate(GROUPS)
    })


def predict(model, prep, factors, beta, ridge, input_equivalence):
    fixed, residual, free, target, origins = prep
    p=model._past_map[:,4*N:]
    g_lift=model._lift_free[:,4*N:]
    future=model._forced[:,4*N:]
    err, diag = [],[]
    for g0, prior, y0, gt in zip(fixed,residual,free,target):
        start=perf_counter()
        latent=linalg.cho_solve(factors,beta*(p.T@prior)-ridge*(g_lift.T@g0),check_finite=False)
        y=y0+(future@latent).reshape(N,9)
        r=p@latent-prior
        g=g0+g_lift@latent
        value=y-gt
        value[:,8]=(value[:,8]+np.pi)%(2*np.pi)-np.pi
        error_cost=float(r@r)
        coefficient=float(g@g)
        elapsed=1e6*(perf_counter()-start)
        err.append(value)
        diag.append([np.sqrt(error_cost/len(r)),np.sqrt(coefficient),.5*ridge*coefficient,.5*beta*error_cost,elapsed])
    square=np.square(np.asarray(err))
    diag=np.asarray(diag)
    return dict(windows=len(origins),full=metric(np.sqrt(square.mean(axis=(0,1)))),
        terminal=metric(np.sqrt(square[:,-1].mean(axis=0))),
        step_rmse_axes_si=np.sqrt(square.mean(axis=0)).tolist(),
        init_slack=float(diag[:,0].mean()),g_norm=float(diag[:,1].mean()),
        g_penalty=float(diag[:,2].mean()),init_penalty=float(diag[:,3].mean()),
        timing_us=np.percentile(diag[:,-1],PCTS).tolist(),
        input_equality_error=input_equivalence), np.c_[origins,square.mean(axis=1),square[:,-1],diag]


def aggregate(rows):
    groups={}
    for r in rows:
        key=(r["profile"],r["rho"],r["beta"])
        groups.setdefault(key,[]).append(r)
    summary=[]
    for (level,rho,beta), members in groups.items():
        present=[r for r in members if r["status"]=="ok"]
        result=dict(profile=level,rho=rho,beta=beta,episode_count=len(present))
        if len(present)!=11:
            result["status"]="incomplete"
            summary.append(result)
            continue
        assert len({r["episode"] for r in present})==11
        result["status"]="ok"
        for metric_type in ("full","terminal"):
            result[metric_type]={}
            for group in (*GROUPS,"axes_si"):
                vals=np.asarray([r[metric_type][group] for r in present])
                folds=np.asarray([vals[[r["fold"]==f for r in present]].mean(axis=0) for f in range(1,6)])
                result[metric_type][group]=dict(episode_mean=vals.mean(axis=0).tolist(),
                    fold_values=folds.tolist(), fold_mean=folds.mean(axis=0).tolist(),
                    fold_sd=folds.std(axis=0,ddof=1).tolist(), worst_fold=folds.max(axis=0).tolist())
        for key in ("init_slack","g_norm","g_penalty","init_penalty"):
            vals=np.array([r[key] for r in present])
            folds=np.array([vals[[r["fold"]==f for r in present]].mean() for f in range(1,6)])
            result[key]=dict(episode_mean=float(vals.mean()),fold_values=folds.tolist(),
                             fold_sd=float(folds.std(ddof=1)),worst_fold=float(folds.max()))
        summary.append(result)
    return summary


def select(summary):
    measures={(r["profile"],r["rho"],r["beta"]):r for r in summary}
    decisions=[]
    def value(r,g):
        return r["full"][g]["episode_mean"]
    for (_,rho,beta), _ in [(k,v) for k,v in measures.items() if k[0]=="L1a"]:
        row=dict(rho=rho,beta=beta,levels={})
        if (rho,beta)==CURRENT:
            row["status"]="reference"
            decisions.append(row)
            continue
        passed=True
        for level in ("L0","L1a","L1b"):
            a=measures[level,rho,beta]
            b=measures[(level,*CURRENT)]
            if a["status"]!="ok" or b["status"]!="ok":
                row["levels"][level]={"pass":False,"incomplete":True}
                passed=False
                continue
            ratio={g:value(a,g)/value(b,g) for g in GROUPS}
            wins=sum(x<y for x,y in zip(a["full"]["xyz_mm"]["fold_values"],b["full"]["xyz_mm"]["fold_values"]))
            gate=all(v<=1.1 for v in ratio.values())
            if level!="L0":
                gate=gate and ratio["xyz_mm"]<=.9 and wins>=4 and sum(v<1 for v in ratio.values())>=2
            row["levels"][level]=dict(pass_gate=gate,ratio=ratio,fold_wins=wins)
            passed=passed and gate
        row["status"]="eligible" if passed else "not_advanced"
        decisions.append(row)
    selected=sorted([r for r in decisions if r["status"]=="eligible"],
                    key=lambda r:(value(measures["L1a",r["rho"],r["beta"]],"xyz_mm"),r["rho"],r["beta"]))[:2]
    return decisions, [(r["rho"],r["beta"]) for r in selected]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folds",type=Path)
    parser.add_argument("output",type=Path)
    a=parser.parse_args()
    a.output.mkdir()
    spec=json.loads(a.folds.read_text())
    root=Path("log/phase3-v1").resolve()
    manifest=json.loads((root/"manifest.json").read_text())
    train={item["processed"]:item for item in manifest["episodes"] if item["split"]=="train"}
    assert sorted(train)==spec["episode_order"]
    assert Counter(x for f in spec["folds"] for x in f["held_out"])==Counter(train.keys())
    data={}
    for name in spec["episode_order"]:
        with np.load(root/name) as record:
            data[name]={k:record[k] for k in ("u","y","truth")}
    cache, folds, noise_log = {}, [], []
    rows, factorizations, raw = [], [], {}
    def prepared(fid,name,level):
        e=data[name]
        seed=spec["seeds"][level]
        ordinal=spec["episode_order"].index(name)
        actual_seed=int(np.random.SeedSequence([seed or 0,ordinal]).generate_state(1)[0])
        y, fingerprint=observed(e["y"],actual_seed,int(level[1]))
        noise_log.append(dict(fold=fid,episode=name,profile=level,episode_seed=actual_seed,sha256=fingerprint))
        return prepare(cache[fid]["model"],e,y)

    def evaluate(profile,combinations):
        for fid,work in cache.items():
            m=work["model"]
            p=m._past_map[:,4*N:]
            g=m._lift_free[:,4*N:]
            prepared_data={name:prepared(fid,name,profile) for name in work["held_out"]}
            for rho,beta in combinations:
                ridge=(rho*work["sigma_max"])**2
                try:
                    start=perf_counter()
                    fac=linalg.cho_factor(beta*(p.T@p)+ridge*(g.T@g),check_finite=False)
                    factorizations.append(dict(fold=fid,profile=profile,rho=rho,beta=beta,
                                               lambda_g=ridge,setup_us=(perf_counter()-start)*1e6))
                    failure=None
                except (ValueError,linalg.LinAlgError) as e:
                    failure=str(e)
                for name,items in prepared_data.items():
                    row=dict(fold=fid,episode=name,profile=profile,rho=rho,beta=beta,lambda_g=ridge)
                    try:
                        if failure:
                            raise ValueError(failure)
                        audit=None
                        if (rho,beta)==CURRENT:
                            # Verify the g lift for one real conditional origin
                            # against the measured physical input history/future.
                            fixed=items[0][0]
                            k=items[-1][0]
                            expected=(data[name]["u"][k-T:k+N]/m._us).ravel()
                            audit=float(np.max(np.abs(work["hankel"]@fixed-expected)))
                        summary, metrics=predict(m,items,fac,beta,ridge,audit)
                        key=f"F{fid}-{name.removesuffix('.npz')}-{profile}-r{rho:g}-b{beta:g}"
                        if not np.all(np.isfinite(metrics)):
                            raise ValueError("non-finite prediction diagnostics")
                        raw[key]=metrics
                        row.update(summary,status="ok",window_key=key)
                    except (ValueError,linalg.LinAlgError) as e:
                        row.update(status="failed",error=str(e))
                    rows.append(row)

    with TemporaryDirectory(prefix="phase531-train-folds-") as workdir:
        tmp=Path(workdir)
        for fold in spec["folds"]:
            fid=fold["fold"]
            assert sorted(set(fold["train"]+fold["held_out"]))==sorted(train)
            assert not set(fold["train"]) & set(fold["held_out"])
            selected=[dict(train[name],processed=str(root/name)) for name in fold["train"]]
            folder=tmp/f"fold-{fid}"
            folder.mkdir()
            (folder/"manifest.json").write_text(json.dumps(dict(manifest,episodes=selected)))
            try:
                start=perf_counter()
                cfg=OuterLoopDeePCConfig(dataset=str(folder),past=T,horizon=N,
                                         regularization=CURRENT[0],initialization_weight=CURRENT[1])
                m=OuterLoopDeePCController(cfg)
                build_time=perf_counter()-start
                u,y=training_blocks(cfg)
                h,info=diagnose_model(m,u,y,[data[name] for name in fold["train"]])
                pe=info["pe"]["9"]
                passed=pe["rank_1e4"]==pe["shape"][0] and bool(info["latent_rank"])
                folds.append(dict(fold,**info,build_seconds=build_time,status="passed" if passed else "failed_pe"))
                if passed:
                    cache[fid]=dict(held_out=fold["held_out"],model=m,hankel=h,sigma_max=info["input"]["sigma_max"])
            except (ValueError,linalg.LinAlgError) as e:
                folds.append(dict(fold,status="failed",error=str(e)))
        write(a.output/"fold-diagnostics.json",folds)
        combinations=[(rho,beta) for rho in spec["rho"] for beta in spec["beta"]]
        if len(cache)==5:
            for level in ("L0","L1a","L1b"):
                evaluate(level,combinations)
            eligibility, extra=select(aggregate(rows))
            evaluate("L2",[CURRENT,*extra])
        else:
            eligibility,extra=[],[]
        write(a.output/"episode-metrics.json",rows)
        write(a.output/"summary.json",dict(five_fold_gate=len(cache)==5, candidates=aggregate(rows),
              current=list(CURRENT), additional=extra, eligibility=eligibility, factorizations=factorizations,
              episode_noise=noise_log,window_columns=["origin",*[f"full_mse_{i}" for i in range(9)],
                    *[f"terminal_se_{i}" for i in range(9)],"init_slack_rms","g_norm","g_penalty","init_penalty","timing_us"]))
        np.savez_compressed(a.output/"window-metrics.npz",**raw)


if __name__=="__main__":
    main()
